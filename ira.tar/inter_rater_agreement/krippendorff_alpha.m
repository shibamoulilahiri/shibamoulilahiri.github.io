function [ alpha ] = krippendorff_alpha ( X , Y )

noOfLevels = 5 ;

data = horzcat ( X , Y ) ;

% First define the coincidence matrix
c_mat = zeros ( noOfLevels , noOfLevels ) ;

for i = 1 : size ( data , 1 )
    
    c_mat ( data ( i , 1 ) , data ( i , 2 ) ) = c_mat ( data ( i , 1 ) , data ( i , 2 ) ) + 1 ;
    
    c_mat ( data ( i , 2 ) , data ( i , 1 ) ) = c_mat ( data ( i , 2 ) , data ( i , 1 ) ) + 1 ;
    
end

numerator = 0 ;
denominator = 0 ;

for i = 1 : noOfLevels
    
    for j = i + 1 : noOfLevels
        
        n_c = sum ( c_mat ( i , : ) ) ;
        
        n_k = sum ( c_mat ( : , j ) ) ;
        
        sum_n_g = 0 ;
        
        for k = i + 1 : j - 1
            
            sum_n_g = sum_n_g + sum ( c_mat ( k , : ) ) ;
            
        end
        
        numerator = numerator + c_mat ( i , j ) * ( n_c / 2 + sum_n_g + n_k / 2 ) ^ 2 ;
        
        denominator = denominator + n_c * n_k * ( n_c / 2 + sum_n_g + n_k / 2 ) ^ 2 ;
        
    end
    
end

alpha = 1 - ( sum ( sum ( c_mat ) ) - 1 ) * numerator / denominator ;
