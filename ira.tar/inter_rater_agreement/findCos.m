function [ retVal ] = findCos (X , Y)

retVal = dot ( X , Y ) / ( norm ( X ) * norm ( Y ) );