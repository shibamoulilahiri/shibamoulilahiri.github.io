function [ tau ] = tau_b ( X , Y )

[ C D ] = findPairs ( X , Y ) ;

[ X_0 Y_0 ] = findTies ( X , Y ) ;

tau = ( C - D ) / sqrt ( ( C + D + X_0 ) * ( C + D + Y_0 ) ) ;
