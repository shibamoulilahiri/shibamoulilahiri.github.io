close all;
clear all;

inpath = '../../to MATLAB/' ;

% 5 inputs - blog, forum, news, paper and total

blog =  importdata([inpath 'blog.txt']);
forum =  importdata([inpath 'forum.txt']);
news =  importdata([inpath 'news.txt']);
paper =  importdata([inpath 'paper.txt']);
total =  importdata([inpath 'total.txt']);


% [ blog_spearman , blog_p ] = corr ( blog(:,1) , blog(:,2) , 'type' , 'Spearman' )
% [ forum_spearman , forum_p ] = corr ( forum(:,1) , forum(:,2) , 'type' , 'Spearman' )
% [ news_spearman , news_p ] = corr ( news(:,1) , news(:,2) , 'type' , 'Spearman' )
% [ paper_spearman , paper_p ] = corr ( paper(:,1) , paper(:,2) , 'type' , 'Spearman' )
% [ total_spearman , total_p ] = corr ( total(:,1) , total(:,2) , 'type' , 'Spearman' )


% blog_quadrant_corr = quadrantCorr ( blog(:,1) , blog(:,2) )
% forum_quadrant_corr = quadrantCorr ( forum(:,1) , forum(:,2) )
% news_quadrant_corr = quadrantCorr ( news(:,1) , news(:,2) )
% paper_quadrant_corr = quadrantCorr ( paper(:,1) , paper(:,2) )
% total_quadrant_corr = quadrantCorr ( total(:,1) , total(:,2) )


% blog_gamma_corr = gammaCorr ( blog(:,1) , blog(:,2) )
% forum_gamma_corr = gammaCorr ( forum(:,1) , forum(:,2) )
% news_gamma_corr = gammaCorr ( news(:,1) , news(:,2) )
% paper_gamma_corr = gammaCorr ( paper(:,1) , paper(:,2) )
% total_gamma_corr = gammaCorr ( total(:,1) , total(:,2) )

% blog_tau_b = tau_b ( blog(:,1) , blog(:,2) )
% forum_tau_b = tau_b ( forum(:,1) , forum(:,2) )
% news_tau_b = tau_b ( news(:,1) , news(:,2) )
% paper_tau_b = tau_b ( paper(:,1) , paper(:,2) )
% total_tau_b = tau_b ( total(:,1) , total(:,2) )
% 
% blog_krippendorff_alpha = krippendorff_alpha ( blog(:,1) , blog(:,2) )
% forum_krippendorff_alpha = krippendorff_alpha ( forum(:,1) , forum(:,2) )
% news_krippendorff_alpha = krippendorff_alpha ( news(:,1) , news(:,2) )
% paper_krippendorff_alpha = krippendorff_alpha ( paper(:,1) , paper(:,2) )
% total_krippendorff_alpha = krippendorff_alpha ( total(:,1) , total(:,2) )

% blog_p = bootstrap ( blog(:,1) , blog(:,2) )
% forum_p = bootstrap ( forum(:,1) , forum(:,2) )
% news_p = bootstrap ( news(:,1) , news(:,2) )
% paper_p = bootstrap ( paper(:,1) , paper(:,2) )
% total_p = bootstrap ( total(:,1) , total(:,2) )

blog_p = bootstrap_krippendorff_alpha ( blog(:,1) , blog(:,2) )
forum_p = bootstrap_krippendorff_alpha ( forum(:,1) , forum(:,2) )
news_p = bootstrap_krippendorff_alpha ( news(:,1) , news(:,2) )
paper_p = bootstrap_krippendorff_alpha ( paper(:,1) , paper(:,2) )
total_p = bootstrap_krippendorff_alpha ( total(:,1) , total(:,2) )


