function [ retVal ] = findTani (X , Y)

retVal = dot ( X , Y ) / ( dot ( X , X ) + dot ( Y , Y ) - dot ( X , Y ) );