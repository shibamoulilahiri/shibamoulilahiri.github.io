function [ C , D ] = findPairs ( X , Y )

C = 0 ;
D = 0 ;

data = horzcat ( X , Y ) ;

for i = 1 : size ( data , 1 )
    
    for j = ( i + 1 ) : size ( data , 1 )
        
        if ( ( data ( i , 1 ) < data ( j , 1 ) && data ( i , 2 ) < data ( j , 2 ) ) || ( data ( i , 1 ) > data ( j , 1 ) && data ( i , 2 ) > data ( j , 2 ) ) )
            C = C + 1 ;
        elseif ( ( data ( i , 1 ) < data ( j , 1 ) && data ( i , 2 ) > data ( j , 2 ) ) || ( data ( i , 1 ) > data ( j , 1 ) && data ( i , 2 ) < data ( j , 2 ) ) )
            D = D + 1 ;
        end
        
    end
    
end
