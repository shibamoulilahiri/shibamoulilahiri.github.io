function [ pval ] = bootstrap ( X , Y )

nboot = 1000 ;

bootstat = bootstrp ( nboot , @tau_b , X , Y ) ;

observed = tau_b ( X , Y );

pval = sum ( sum ( bootstat <= 0 ) ) / nboot ;
