function [ X_0 , Y_0 ] = findTies ( X , Y )

X_0 = 0 ;
Y_0 = 0 ;

data = horzcat ( X , Y ) ;

for i = 1 : size ( data , 1 )
    
    for j = ( i + 1 ) : size ( data , 1 )
        
        if ( data ( i , 1 ) == data ( j , 1 ) )
            X_0 = X_0 + 1 ;
        elseif ( data ( i , 2 ) == data ( j , 2 ) )
            Y_0 = Y_0 + 1 ;
        end
        
    end
    
end
