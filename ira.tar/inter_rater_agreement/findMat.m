function [ mat ] = findMat ( X , Y )

maxxy = 5 ; % It should be the maximum value in the Likert Scale
minxy = 1 ; % It should be the minimum value in the Likert Scale

mat = zeros ( maxxy + 1 - minxy ) ;

data = horzcat ( X , Y ) ;

for i = 1 : size ( data , 1 )
    
    mat ( data ( i , 1 ) , data ( i , 2 ) ) = mat ( data ( i , 1 ) , data ( i , 2 ) ) + 1 ;
    
end
