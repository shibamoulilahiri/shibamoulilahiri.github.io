function [ gamma ] = gammaCorr (X , Y)

[ C D ] = findPairs ( X , Y ) ;

gamma = ( C - D ) / ( C + D );