close all;
clear all;

inpath = '../../to MATLAB/' ;

% 5 inputs - blog, forum, news, paper and total

blog =  importdata([inpath 'blog.txt']);
forum =  importdata([inpath 'forum.txt']);
news =  importdata([inpath 'news.txt']);
paper =  importdata([inpath 'paper.txt']);
total =  importdata([inpath 'total.txt']);



blog_cosine = findCos ( blog(:,1) , blog(:,2) )
forum_cosine = findCos ( forum(:,1) , forum(:,2) )
news_cosine = findCos ( news(:,1) , news(:,2) )
paper_cosine = findCos ( paper(:,1) , paper(:,2) )
total_cosine = findCos ( total(:,1) , total(:,2) )

blog_tanimoto = findTani ( blog(:,1) , blog(:,2) )
forum_tanimoto = findTani ( forum(:,1) , forum(:,2) )
news_tanimoto = findTani ( news(:,1) , news(:,2) )
paper_tanimoto = findTani ( paper(:,1) , paper(:,2) )
total_tanimoto = findTani ( total(:,1) , total(:,2) )

% kappa ( findMat ( blog(:,1) , blog(:,2) ) )
% kappa ( findMat ( forum(:,1) , forum(:,2) ) )
% kappa ( findMat ( news(:,1) , news(:,2) ) )
% kappa ( findMat ( paper(:,1) , paper(:,2) ) )
% kappa ( findMat ( total(:,1) , total(:,2) ) )
