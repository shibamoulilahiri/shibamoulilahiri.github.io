function [ pval ] = bootstrap_krippendorff_alpha ( X , Y )

% First compute the observed alpha

noOfLevels = 5 ;

data = horzcat ( X , Y ) ;

% First define the coincidence matrix
c_mat = zeros ( noOfLevels , noOfLevels ) ;

for i = 1 : size ( data , 1 )
    
    c_mat ( data ( i , 1 ) , data ( i , 2 ) ) = c_mat ( data ( i , 1 ) , data ( i , 2 ) ) + 1 ;
    
    c_mat ( data ( i , 2 ) , data ( i , 1 ) ) = c_mat ( data ( i , 2 ) , data ( i , 1 ) ) + 1 ;
    
end

numerator = 0 ;
denominator = 0 ;

for i = 1 : noOfLevels
    
    for j = i + 1 : noOfLevels
        
        n_c = sum ( c_mat ( i , : ) ) ;
        
        n_k = sum ( c_mat ( : , j ) ) ;
        
        sum_n_g = 0 ;
        
        for k = i + 1 : j - 1
            
            sum_n_g = sum_n_g + sum ( c_mat ( k , : ) ) ;
            
        end
        
        numerator = numerator + c_mat ( i , j ) * ( n_c / 2 + sum_n_g + n_k / 2 ) ^ 2 ;
        
        denominator = denominator + n_c * n_k * ( n_c / 2 + sum_n_g + n_k / 2 ) ^ 2 ;
        
    end
    
end

alpha_observed = 1 - ( sum ( sum ( c_mat ) ) - 1 ) * numerator / denominator

% Now bootstrap

m = 2 ; % No of observers

X = 1000 ; % No of bootstraps

N_alpha = zeros ( size ( -1 : 0.0001 : 1 , 2 ) , 1 ) ;

n_dot_dot = sum ( sum ( c_mat ) ) ;

Q = sum ( sum ( c_mat > 0 ) ) ;

F = m - 1 ;

M = min ( [ 100 * Q , F * n_dot_dot ] ) ;

B = 1 / ( M * denominator ) ;

p_c_k = c_mat / n_dot_dot ;

cum_mat = p_c_k ;

for i = 1 : size ( cum_mat , 1 )
    
    for j = 1 : size ( cum_mat , 2 )
        
        if ( i > 1 && j == 1 )
            
            cum_mat ( i , j ) = cum_mat ( i - 1 , size ( cum_mat , 2 ) ) + cum_mat ( i , j ) ;
            
        elseif ( j > 1 )
            
            cum_mat ( i , j ) = cum_mat ( i , j - 1 ) + cum_mat ( i , j ) ;
            
        end
        
    end
    
end

for i = 1 : X
    
    loop_sum = 0 ;
    
    for j = 1 : M
        
        R = rand ;
        
        del_c_k_square = findck ( R , cum_mat , c_mat ) ;
        
        loop_sum = loop_sum + del_c_k_square ;
        
    end
    
    alpha = 1 - B * loop_sum ;
    
    if ( alpha < -1 )
        
        N_alpha ( 1 , 1 ) = N_alpha ( 1 , 1 ) + 1 ;
        
    else
        
        % Convert alpha to index N_alpha
        
        N_alpha ( int16 ( alpha * 10000 + 10001 ) , 1 ) = N_alpha ( int16 ( alpha * 10000 + 10001 ) , 1 ) + 1 ;
        
    end
    
end

% Correction for N_alpha_one

if ( trace ( c_mat ) == 0 )
    
    N_alpha ( 20001 , 1 ) = 0 ;
    
elseif ( sum ( diag ( c_mat ) > 0 ) == 1 )
    
    N_alpha ( 10001 , 1 ) = N_alpha ( 10001 , 1 ) + N_alpha ( 20001 , 1 ) ;
    
    N_alpha ( 20001 , 1 ) = 0 ;
    
elseif ( sum ( diag ( c_mat ) > 0 ) > 1 )
    
    N_x = X * sum ( ( diag ( c_mat ) / n_dot_dot ) .^ M ) ;
    
    if ( N_x >= N_alpha ( 20001 , 1 ) )
        
        N_alpha ( 10001 , 1 ) = N_alpha ( 10001 , 1 ) + N_alpha ( 20001 , 1 ) ;
        
        N_alpha ( 20001 , 1 ) = 0 ;
        
    else
        
        N_alpha ( 20001 , 1 ) = N_alpha ( 20001 , 1 ) - N_x ;
        
        N_alpha ( 10001 , 1 ) = N_alpha ( 10001 , 1 ) + N_x ;
        
    end
    
end

pval = sum ( N_alpha ( 1 : 10001 ) / X ) ;


