function [ del_c_k_square ] = findck ( R , cum_mat , c_mat )

c = 0 ;
k = 0 ;

for i = 1 : size ( cum_mat , 1 )
    
    for j = 1 : size ( cum_mat , 2 )
        
        if ( i == 1 && j == 1 && R <= cum_mat ( i , j ) )
            
            c = 1 ;
            k = 1 ;
            
        elseif ( i > 1 && j == 1 && R <= cum_mat ( i , j ) && R >= cum_mat ( i - 1 , size ( cum_mat , 2 ) ) )
            
            c = i ;
            k = j ;
            
        elseif ( j > 1 && R <= cum_mat ( i , j ) && R >= cum_mat ( i , j - 1 ) )
            
            c = i ;
            k = j ;
            
        end
        
    end
    
end



n_c = sum ( c_mat ( c , : ) ) ;

n_k = sum ( c_mat ( : , k ) ) ;

sum_n_g = 0 ;

for g = c + 1 : k - 1
    
    sum_n_g = sum_n_g + sum ( c_mat ( g , : ) ) ;
    
end



del_c_k_square = ( n_c / 2 + sum_n_g + n_k / 2 ) ^ 2 ;
