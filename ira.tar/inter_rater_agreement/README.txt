In this class, we are going to use Matlab, a proprietary software developed by Mathworks, Inc.

Matlab is very useful for dealing with numbers, numerical data, matrices and vectors.

Matlab is available in Hammer, Lion-XO, Lion-XA, Lion-XB, and all other clusters, including Cyberstar.

To enter Matlab, please type in the following commands in succession:

$ module load matlab

$ matlab -r -nosplash -nodisplay

Matlab might take some time to load, so please hold on.



**************************
*                        *
* Basic Coding In Matlab *
*                        *
**************************

When you enter Matlab, you'll see a prompt:

>>

You can write commands (just like in Python) to instruct Matlab on what to do:

>> x
??? Undefined function or variable 'x'.
 
>> x = 5

x =

     5


Matlab has two modes like Python - the command-line mode and the script mode. For the purpose of this class, we will only use the command-line mode. We will not cover cell arrays, and give only a cursory introduction to strings.


Matlab can be used to define variables, as shown above. It can also be used to add, subtract, multiply or divide:


>> 3 + 4

ans =

     7

>> 3 - 4

ans =

    -1

>> 3 * 4

ans =

    12

>> 3 / 4

ans =

    0.7500



--------------
MORE OPERATORS
--------------


>> x = 10

x =

    10

>> y = 5

y =

     5

>> mod ( x , y )   % A built-in

ans =

     0

>> x ^ y

ans =

      100000



-------
VECTORS
-------


>> [1 2 3]

ans =

     1     2     3

>> [1 2 3]'

ans =

     1
     2
     3

>> [1
2
3]

ans =

     1
     2
     3

>> x = [1 2 3]

x =

     1     2     3

>> x = [1 2 3]'

x =

     1
     2
     3

>> x = [1,2,3]

x =

     1     2     3

>> x = [1,2,3]'

x =

     1
     2
     3



----------------
VECTOR OPERATORS
----------------


>> x = [ 1 2 3 ]

x =

     1     2     3

>> y = [ 4 5 6 ]

y =

     4     5     6

>> x + y

ans =

     5     7     9

>> x - y

ans =

    -3    -3    -3

>> x * y
??? Error using ==> mtimes
Inner matrix dimensions must agree.
 
>> x / y   % Intuition behind this output is fairly complicated. Let's skip this.

ans =

    0.4156


>> x .* y

ans =

     4    10    18
     
>> x ./ y

ans =

    0.2500    0.4000    0.5000


>> dot ( x , y )   % Another built-in

ans =

    32



>> x * y'

ans =

    32

>> x' * y

ans =

     4     5     6
     8    10    12
    12    15    18


>> cross ( x , y )   % Yet another built-in

ans =

    -3     6    -3



--------
MATRICES
--------

Matlab can also handle matrices, much in the same way as vectors. The basic operators remain the same.



>> x = [ 1 2 3 ; 4 5 6 ; 7 8 9 ]

x =

     1     2     3
     4     5     6
     7     8     9

>> y = [ 10 20 30 ; 40 50 60 ; 70 80 90 ]

y =

    10    20    30
    40    50    60
    70    80    90

>> x + y

ans =

    11    22    33
    44    55    66
    77    88    99

>> x - y

ans =

    -9   -18   -27
   -36   -45   -54
   -63   -72   -81

>> x * y

ans =

         300         360         420
         660         810         960
        1020        1260        1500

>> x / y
Warning: Matrix is singular to working precision. 

ans =

   NaN   NaN   NaN
   NaN   NaN   NaN
   NaN   NaN   NaN

>> y / x
Warning: Matrix is singular to working precision. 

ans =

   NaN   NaN   NaN
   NaN   NaN   NaN
   NaN   NaN   NaN

>> x .* y

ans =

    10    40    90
   160   250   360
   490   640   810

>> x ./ y

ans =

    0.1000    0.1000    0.1000
    0.1000    0.1000    0.1000
    0.1000    0.1000    0.1000



--------------------------------------
PRINTING OUTPUT AND SUPPRESSING OUTPUT
--------------------------------------

>> x = 5 ;
>> x

x =

     5

>> x = [ 1 2 3 ]' ;
>> x

x =

     1
     2
     3



---------------------
READ DATA FROM A FILE
---------------------

>> x = importdata ('rater_1.txt') ;   % "importdata" is a built-in
>> y = importdata ('rater_2.txt') ;



1> Each input file contains either a number, or a vector, or a matrix. In case of a vector, elements need to be separated by space (row vector) or newline (column vector). In case of matrices, each row will be on a separate line, and elements in a row will be separated from each other by a space or tab.

2> There can be several input files. These files should be put together in a directory. Path to this directory is called "inpath". For more complex scenarios, there can be multiple inpaths ("inpath_1", "inpath_2", etc).

3> In our case, there are two files - "rater_1.txt" and "rater_2.txt", and each file contains a column vector (of sentence formality ratings).



>> inpath = '~/578/inter_rater_agreement/' ;         % In our case, we don't need this, because inpath is SAME as current directory.
>> x = importdata ( [inpath 'rater_1.txt'] ) ;
>> y = importdata ( [inpath 'rater_2.txt'] ) ;.



-------------------
NOW THE FUN PART !!
-------------------

% Among the following functions, "corr" is a built-in. Others were developed by Shibamouli Lahiri (except "kappa").


>> corr ( x , y )                             % Pearson Correlation Coefficient
>> corr ( x , y , 'type' , 'Spearman' )       % Spearman Correlation Coefficient
>> corr ( x , y , 'type' , 'Kendall' )        % Kendall's Tau_a


>> tau_b ( x , y )                            % Kendall's Tau_b
>> gammaCorr ( x , y )                        % Goodman and Kruskal's Gamma Test


>> findCos ( x , y )                          % Cosine Similarity
>> findTani ( x , y )                         % Tanimoto Similarity


>> kappa ( findMat ( x , y ) )                % Cohen's Kappa
>> krippendorff_alpha ( x , y )               % Krippendorff's Alpha



--------------------------------------------------------------
Matlab tutorial: http://www.math.ufl.edu/help/matlab-tutorial/
--------------------------------------------------------------


