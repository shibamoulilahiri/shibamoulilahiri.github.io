library(ROCR)

png("adding_positional_features.png")

mydata = read.table("all_features.txt", header=TRUE)
mymodel = glm(is_keyphrase~log_tf+commonness+full_np+full_vp+partial_np+partial_vp+first_word_olw+last_word_head_noun+full_tt+full_ctt+partial_tt+partial_ctt+presence_in_first_sentence+absolute_first_occurrence+relative_first_occurrence, data=mydata, family=binomial(logit), weights=c(rep(1,times=7816), rep(0.1,times=78160)))
mydata$predictions = predict(mymodel, newdata = mydata, type="response")
pred = prediction(mydata$predictions, mydata$is_keyphrase)
perf = performance(pred, measure = "prec", x.measure = "rec") 
plot(perf, col="red", lwd=4)
par(new=T, xaxt="n", yaxt="n", ann=FALSE)

mydata = read.table("all_features.txt", header=TRUE)
mymodel = glm(is_keyphrase~log_tf+full_tt+full_ctt+partial_tt+partial_ctt+presence_in_first_sentence+absolute_first_occurrence+relative_first_occurrence, data=mydata, family=binomial(logit), weights=c(rep(1,times=7816), rep(0.1,times=78160)))
mydata$predictions = predict(mymodel, newdata = mydata, type="response")
pred = prediction(mydata$predictions, mydata$is_keyphrase)
perf = performance(pred, measure = "prec", x.measure = "rec") 
plot(perf, col="black", lwd=4)
par(new=T, xaxt="n", yaxt="n", ann=FALSE)

mydata = read.table("all_features.txt", header=TRUE)
mymodel = glm(is_keyphrase~log_tf+commonness, data=mydata, family=binomial(logit), weights=c(rep(1,times=7816), rep(0.1,times=78160)))
mydata$predictions = predict(mymodel, newdata = mydata, type="response")
pred = prediction(mydata$predictions, mydata$is_keyphrase)
perf = performance(pred, measure = "prec", x.measure = "rec") 
plot(perf, col="blue", lwd=4)
par(new=T, xaxt="n", yaxt="n", ann=FALSE)

mydata = read.table("all_features.txt", header=TRUE)
mymodel = glm(is_keyphrase~G_2, data=mydata, family=binomial(logit), weights=c(rep(1,times=7816), rep(0.1,times=78160)))
mydata$predictions = predict(mymodel, newdata = mydata, type="response")
pred = prediction(mydata$predictions, mydata$is_keyphrase)
perf = performance(pred, measure = "prec", x.measure = "rec") 
plot(perf, col="lightblue", lwd=4)
par(new=T, xaxt="n", yaxt="n", ann=FALSE)

mydata = read.table("all_features.txt", header=TRUE)
mymodel = glm(is_keyphrase~log_tf, data=mydata, family=binomial(logit), weights=c(rep(1,times=7816), rep(0.1,times=78160)))
mydata$predictions = predict(mymodel, newdata = mydata, type="response")
pred = prediction(mydata$predictions, mydata$is_keyphrase)
perf = performance(pred, measure = "prec", x.measure = "rec") 
plot(perf, col="orange", lwd=4)

legend("topright", c("all features","corpus-independent model","log(tf) + commonness","G_2","log(tf)"), text.col=c("red","black","blue","lightblue","orange"), col=c("red","black","blue","lightblue","orange"), lwd=4)

dev.off()



