# This script computes corpus commonness of terms (up to and including 5-grams), on INSPEC corpus.

import glob, math, re, sys

corpus_cnt  =  int(sys.argv[1])  # How many times (at minimum) an ngram has to appear in the background corpus.

indir       =  "/local/shibamouli/EECS592/replication_project/INSPEC/all_texts/"
all_files   =  glob.glob(indir + "*txt")
tot_count   =  len(all_files)
assert(tot_count == 2000)

dict_uni    =  {}  # Stores count of unigrams.
dict_bi     =  {}
dict_tri    =  {}
dict_four   =  {}
dict_five   =  {}

comm_uni    =  {}  # Stores corpus commonness of unigrams.
comm_bi     =  {}
comm_tri    =  {}
comm_four   =  {}
comm_five   =  {}


for fID, infilename in enumerate(all_files, 1):

    infile     =  open(infilename, "r")
    all_lines  =  filter(lambda x: len(x) > 0, [line.strip() for line in infile.readlines()])
    all_lines  =  filter(lambda x: len(x) > 0, [re.sub("\s+", " ", line.replace("\n", " ").replace("\r", " ").strip()) for line in all_lines])
    big_text   =  " ".join(all_lines).lower()
    infile.close()

    unigrams   =  big_text.split()
    bigrams    =  [" ".join(x) for x in zip(unigrams, unigrams[1:])]
    trigrams   =  [" ".join(x) for x in zip(unigrams, unigrams[1:], unigrams[2:])]
    fourgrams  =  [" ".join(x) for x in zip(unigrams, unigrams[1:], unigrams[2:], unigrams[3:])]
    fivegrams  =  [" ".join(x) for x in zip(unigrams, unigrams[1:], unigrams[2:], unigrams[3:], unigrams[4:])]

    for gram in unigrams: dict_uni[gram]    =  dict_uni.get(gram, 0) + 1
    for gram in bigrams: dict_bi[gram]      =  dict_bi.get(gram, 0) + 1
    for gram in trigrams: dict_tri[gram]    =  dict_tri.get(gram, 0) + 1
    for gram in fourgrams: dict_four[gram]  =  dict_four.get(gram, 0) + 1
    for gram in fivegrams: dict_five[gram]  =  dict_five.get(gram, 0) + 1

    print "Finished", fID, "of", tot_count, "files."


max_uni     =  max(dict_uni.values())
max_bi      =  max(dict_bi.values())
max_tri     =  max(dict_tri.values())
max_four    =  max(dict_four.values())
max_five    =  max(dict_five.values())

for gram in dict_uni: comm_uni[gram]    =  math.log(dict_uni[gram])/math.log(max_uni)
for gram in dict_bi: comm_bi[gram]      =  math.log(dict_bi[gram])/math.log(max_bi)
for gram in dict_tri: comm_tri[gram]    =  math.log(dict_tri[gram])/math.log(max_tri)
for gram in dict_four: comm_four[gram]  =  math.log(dict_four[gram])/math.log(max_four)
for gram in dict_five: comm_five[gram]  =  math.log(dict_five[gram])/math.log(max_five)

infile      =  open("all_filtered_keyphrases_lowercased.txt", "r")
human_key   =  filter(lambda x: len(x) > 0, [line.strip() for line in infile.readlines()])
infile.close()

outfile     =  open("corpus_commonness.txt", "w")
for hk in human_key:
    word_length = len(hk.split())
    '''if word_length == 1 and hk in comm_uni: outfile.write(str(comm_uni[hk]) + "\n")
    if word_length == 2 and hk in comm_bi: outfile.write(str(comm_bi[hk]) + "\n")
    if word_length == 3 and hk in comm_tri: outfile.write(str(comm_tri[hk]) + "\n")
    if word_length == 4 and hk in comm_four: outfile.write(str(comm_four[hk]) + "\n")
    if word_length == 5 and hk in comm_five: outfile.write(str(comm_five[hk]) + "\n")'''
    if word_length == 1 and hk in comm_uni and dict_uni[hk] >= corpus_cnt: outfile.write(str(comm_uni[hk]) + "\n")
    if word_length == 2 and hk in comm_bi and dict_bi[hk] >= corpus_cnt: outfile.write(str(comm_bi[hk]) + "\n")
    if word_length == 3 and hk in comm_tri and dict_tri[hk] >= corpus_cnt: outfile.write(str(comm_tri[hk]) + "\n")
    if word_length == 4 and hk in comm_four and dict_four[hk] >= corpus_cnt: outfile.write(str(comm_four[hk]) + "\n")
    if word_length == 5 and hk in comm_five and dict_five[hk] >= corpus_cnt: outfile.write(str(comm_five[hk]) + "\n")
outfile.close()


print "# unique unigrams =", len(dict_uni)
print "# unique bigrams =", len(dict_bi)
print "# unique trigrams =", len(dict_tri)
print "# unique fourgrams =", len(dict_four)
print "# unique fivegrams =", len(dict_five)



