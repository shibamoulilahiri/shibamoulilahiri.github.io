import csv, os, re, shutil


hit_results_dir = "results/"
if os.path.exists(hit_results_dir): shutil.rmtree(hit_results_dir)
os.makedirs(hit_results_dir)


os.system("grep ted HITs_with_HITTypeID | cut -d':' -f2 | sed 's/\s//g' > hitIDs.txt")


hitID_file  =  open("hitIDs.txt", "r")
hitIDs      =  filter(lambda x: len(x) > 0, [line.strip() for line in hitID_file.readlines()])
hitID_file.close()
total = len(hitIDs)
assert(total == 144)


textfile    =  open("SemEval_filenames", "r")
filenames   =  ["/local/shibamouli/EECS592/SemEval_data/SemEval_train_" + y + ".txt" for y in filter(lambda x: len(x) > 0, [line.strip() for line in textfile.readlines()])]
textfile.close()
assert(len(filenames) == 144)

os.system("cd ../../; ant -DhitID=retrieveAllHITs wellman_keywords")



## To explore the keywords, run:
## sort -u allAnswers.txt | wc -l (there are 17,640 unique keywords in total, separate uppercase/lowercase; after filtering, the number is 17,621)
## sort allAnswers.txt | uniq -c | sort -k1nr | more (to see the keywords sorted by frequency)
## tr '[:upper:]' '[:lower:]' < allAnswers.txt | sort -u | wc -l (there are 15,187 unique keywords in total, all lowercased; after filtering, the number is 15,173)
## tr '[:upper:]' '[:lower:]' < allAnswers.txt | sort | uniq -c | sort -k1nr | more (to see the keywords - all lowercased - sorted by frequency)



## Next step: filtering keyphrases.
##
## Ignore the following keyphrases, and any keyphrase that matches the title, the abstract, or title + abstract.
ignore_dict = { "emptyanswer" : 0,
                "na" : 0,
                "nothing" : 0,
                "optional" : 0,
                "aa" : 0,
                "keyword" : 0,
                "Keyword/Keyphrase 1:  Keyword/Keyphrase 1:" : 0,
                "Keyword/Keyphrase 1:" : 0,
                "NA" : 0,
                "N/A" : 0,
                "n/a" : 0,
                "N/a" : 0,
                "N\A" : 0,
                "Keyword/Keyphrase 1:  vvvvvvvvvvvvvvv" : 0,
                "Keyword/Keyphrase 1:  vvvvvvvvvvvvvvvvvvvvvvvvvvvvv" : 0,
                "Keyword query" : 0,
                "Keywords" : 0,
                "Keywords in a search form" : 0,
                "keywords, titles, and full-text." : 0,
                "vvvvvvvvKeyword/Keyphrase 1:" : 0 }


## Filter allAnswers.txt
infile      =  open("allAnswers.txt", "r")
keywords    =  filter(lambda x: len(x) > 0 and x not in ignore_dict, [line.strip() for line in infile.readlines()])
infile.close()
outfile     =  open("allAnswers_filtered.txt", "w")
outfile.write("\n".join(keywords))
outfile.close()

## Filter keyphrases, assign them to individual documents.
abstr_dir   =  "/local/shibamouli/EECS592/SemEval_data_abstracts_only/"
if os.path.exists(abstr_dir): shutil.rmtree(abstr_dir)
os.makedirs(abstr_dir)

## Filter keyphrases, assign them to individual documents.
results_dir =  "human_assigned_keyphrases/"
if os.path.exists(results_dir): shutil.rmtree(results_dir)
os.makedirs(results_dir)

big_file    =  open("by_assignment.txt", "w")
bigger_dict =  {}  # Stores all filtered keyphrases
lc_dict     =  {}  # Stores all filtered keyphrases (lowrcased)
worker_dict =  {}  # Stores all unique turkers
big_dict_2  =  {}  # Stores all keyphrases of length 5 words or less that appeared in the corresponding document.
big_dict_3  =  {}  # Stores all keyphrases that appeared in the corresponding document.

for hindex, hit in enumerate(hitIDs):
    infile    =  open(hit_results_dir + hit + ".csv", "r")
    reader    =  csv.reader(infile)
    big_dict  =  {}
    textfile  =  open(filenames[hindex], "r")
    all_lines =  filter(lambda x: len(x) > 0, [line.strip() for line in textfile.readlines()])
    title     =  re.sub('\s+', ' ', all_lines[0].lower())
    abstract  =  re.sub('\s+', ' ', " ".join(all_lines[1:]).lower())
    abstract_original = " ".join(all_lines[1:])
    textfile.close()
    abstr_f   =  open(abstr_dir + os.path.basename(filenames[hindex]), "w")
    abstr_f.write(abstract_original + "\n")
    abstr_f.close()
    for rn, row in enumerate(reader):
        if rn == 0: continue ## header row
        assignment_dict = {}
        for cn, col in enumerate(row):
            lc  = re.sub('\s+', ' ', col).lower()
            if cn == 2: worker_dict[col] = 0
            if cn in range(6,22) and col not in ignore_dict and lc not in [title, abstract, title + " " + abstract, abstract + " " + title]:
            #if cn in range(6,22) and col != "emptyanswer":
                col                   =  re.sub('\s+', ' ', col)
                big_dict[col]         =  big_dict.get(col, 0) + 1
                assignment_dict[col]  =  0
                bigger_dict[col]      =  0
                lc_dict[lc]           =  0
                if col in abstract_original and len(filter(lambda x: len(x) > 0, col.strip().split())) <= 5: big_dict_2[col] = big_dict_2.get(col, 0) + 1
                if col in abstract_original: big_dict_3[col] = 0
        big_file.write(str(len(assignment_dict)) + "\n")
    infile.close()
    outfile = open(results_dir + os.path.basename(filenames[hindex]), "w")
    outfile.write("\n".join(big_dict.keys()))
    outfile.close()

    if hindex == 0: print "\n" + "\n".join([":".join([k, str(big_dict_2[k])]) for k in big_dict_2]) + "\n\n" + os.path.basename(filenames[hindex]) + "\n\n"

big_file.close()

big_file   =  open("by_phrase_length.txt", "w")
big_file.write("\n".join([str(len(x.strip().split())) for x in bigger_dict]))
big_file.close()

big_file   =  open("phrases_with_less_than_six_words_that_appeared_in_corresponding_abstract.txt", "w")
big_file.write("\n".join(big_dict_2.keys()))
big_file.close()

big_file   =  open("all_filtered_keyphrases_lowercased.txt", "w")
big_file.write("\n".join(lc_dict.keys()))
big_file.close()

print "\n\nNumber of unique workers:", len(worker_dict)
print "\n\nFraction of keyphrases present in the documents:", len(big_dict_3) * 100.0 / len(bigger_dict), "%"



