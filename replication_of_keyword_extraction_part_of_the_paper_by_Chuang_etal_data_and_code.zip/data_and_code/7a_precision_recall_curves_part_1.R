library(ROCR)

png("frequency_statistics.png")

mydata = read.table("all_features.txt", header=TRUE)
mymodel = glm(is_keyphrase~G_2, data=mydata, family=binomial(logit), weights=c(rep(1,times=7816), rep(0.1,times=78160)))
mydata$predictions = predict(mymodel, newdata = mydata, type="response")
pred = prediction(mydata$predictions, mydata$is_keyphrase)
perf = performance(pred, measure = "prec", x.measure = "rec") 
plot(perf, col="orange", lwd=4)
par(new=T, xaxt="n", yaxt="n", ann=FALSE)

mydata = read.table("all_features.txt", header=TRUE)
mymodel = glm(is_keyphrase~logOdds, data=mydata, family=binomial(logit), weights=c(rep(1,times=7816), rep(0.1,times=78160)))
mydata$predictions = predict(mymodel, newdata = mydata, type="response")
pred = prediction(mydata$predictions, mydata$is_keyphrase)
perf = performance(pred, measure = "prec", x.measure = "rec") 
plot(perf, col="red", lwd=4)
par(new=T, xaxt="n", yaxt="n", ann=FALSE)

mydata = read.table("all_features.txt", header=TRUE)
mymodel = glm(is_keyphrase~BM25, data=mydata, family=binomial(logit), weights=c(rep(1,times=7816), rep(0.1,times=78160)))
mydata$predictions = predict(mymodel, newdata = mydata, type="response")
pred = prediction(mydata$predictions, mydata$is_keyphrase)
perf = performance(pred, measure = "prec", x.measure = "rec") 
plot(perf, col="lightblue", lwd=4)
par(new=T, xaxt="n", yaxt="n", ann=FALSE)

mydata = read.table("all_features.txt", header=TRUE)
mymodel = glm(is_keyphrase~tfidf, data=mydata, family=binomial(logit), weights=c(rep(1,times=7816), rep(0.1,times=78160)))
mydata$predictions = predict(mymodel, newdata = mydata, type="response")
pred = prediction(mydata$predictions, mydata$is_keyphrase)
perf = performance(pred, measure = "prec", x.measure = "rec") 
plot(perf, col="black", lwd=4)
par(new=T, xaxt="n", yaxt="n", ann=FALSE)

mydata = read.table("all_features.txt", header=TRUE)
mymodel = glm(is_keyphrase~log_tf, data=mydata, family=binomial(logit), weights=c(rep(1,times=7816), rep(0.1,times=78160)))
mydata$predictions = predict(mymodel, newdata = mydata, type="response")
pred = prediction(mydata$predictions, mydata$is_keyphrase)
perf = performance(pred, measure = "prec", x.measure = "rec") 
plot(perf, col="blue", lwd=4)

legend("topright", c("G_2","log odds","BM25","tfidf","log(tf)"), text.col=c("orange","red","lightblue","black","blue"), col=c("orange","red","lightblue","black","blue"), lwd=4)

dev.off()



