import glob, numpy, os, random, re
from nltk.tokenize import sent_tokenize


def is_in(term, aList):
    for elem in aList:
        if term in elem:
            return True
    return False


indir       =  "/local/shibamouli/EECS592/SemEval_data/"
all_files   =  glob.glob(indir + "*txt")
tot_count   =  len(all_files)
assert(tot_count == 144)

indir2      =  "/local/shibamouli/EECS592/SemEval_data_abstracts_only/"

results_dir =  "human_assigned_keyphrases/"
key_dict    =  {}
first_dict  =  {}
np_dict     =  {}
vp_dict     =  {}
tt_dict     =  {}
ctt_dict    =  {}

dict_uni    =  {}  # Stores unigrams.
dict_bi     =  {}  # Stores bigrams.
dict_tri    =  {}
dict_four   =  {}
dict_five   =  {}

count_f     =  {}  # Count of all unique terms in first sentences
count_a     =  {}  # Count of all unique terms in all abstracts
count_sent  =  []  # Count of sentences in all abstracts

for fID, infilename in enumerate(all_files, 1):
    infile       =  open(infilename, "r")
    all_lines    =  filter(lambda x: len(x) > 0, [line.strip() for line in infile.readlines()])
    infile.close()
    abstract     =  " ".join(all_lines[1:])
    sentences    =  sent_tokenize(abstract)
    first_sent   =  sentences[0]
    count_sent.append(len(sentences))
    count_f.update({y : 0 for y in filter(lambda x: len(x) > 0, first_sent.split())})
    count_a.update({y : 0 for y in filter(lambda x: len(x) > 0, abstract.split())})

    big_text     =  re.sub("\s+", " ", abstract)
    unigrams     =  big_text.split()
    bigrams      =  [" ".join(x) for x in zip(unigrams, unigrams[1:])]
    trigrams     =  [" ".join(x) for x in zip(unigrams, unigrams[1:], unigrams[2:])]
    fourgrams    =  [" ".join(x) for x in zip(unigrams, unigrams[1:], unigrams[2:], unigrams[3:])]
    fivegrams    =  [" ".join(x) for x in zip(unigrams, unigrams[1:], unigrams[2:], unigrams[3:], unigrams[4:])]

    dict_uni.update({y : 0 for y in unigrams})
    dict_bi.update({y : 0 for y in bigrams})
    dict_tri.update({y : 0 for y in trigrams})
    dict_four.update({y : 0 for y in fourgrams})
    dict_five.update({y : 0 for y in fivegrams})

    infile       =  open(indir2 + os.path.basename(infilename).replace(".txt", ".noun_phrases"), "r")
    noun_phrases =  filter(lambda x: len(x) > 0, [line.strip() for line in infile.readlines()])
    infile.close()
    infile       =  open(indir2 + os.path.basename(infilename).replace(".txt", ".verb_phrases"), "r")
    verb_phrases =  filter(lambda x: len(x) > 0, [line.strip() for line in infile.readlines()])
    infile.close()
    infile       =  open(indir2 + os.path.basename(infilename).replace(".txt", ".technical_terms"), "r")
    tech_terms   =  filter(lambda x: len(x) > 0, [line.strip() for line in infile.readlines()])
    infile.close()
    infile       =  open(indir2 + os.path.basename(infilename).replace(".txt", ".compound_technical_terms"), "r")
    c_tech_terms =  filter(lambda x: len(x) > 0, [line.strip() for line in infile.readlines()])
    infile.close()

    infile       =  open(results_dir + os.path.basename(infilename), "r")
    all_lines    =  filter(lambda x: len(x) > 0, [line.strip() for line in infile.readlines()])
    infile.close()
    key_dict.update({y : 0 for y in all_lines})
    for keyphrase in all_lines:
        if keyphrase in first_sent:
            first_dict[keyphrase] = 0

    for keyphrase in all_lines:
        if is_in(keyphrase, noun_phrases): np_dict[keyphrase]  =  0
        if is_in(keyphrase, verb_phrases): vp_dict[keyphrase]  =  0
        if is_in(keyphrase, tech_terms):   tt_dict[keyphrase]  =  0
        if is_in(keyphrase, c_tech_terms): ctt_dict[keyphrase] =  0

    ## Alternative computation.
    '''for keyphrase in all_lines:
        if is_in(keyphrase, noun_phrases): np_dict[infilename]  =  np_dict.get(infilename, 0) + 1
        if is_in(keyphrase, verb_phrases): vp_dict[infilename]  =  vp_dict.get(infilename, 0) + 1
        if is_in(keyphrase, tech_terms):   tt_dict[infilename]  =  tt_dict.get(infilename, 0) + 1
        if is_in(keyphrase, c_tech_terms): ctt_dict[infilename] =  ctt_dict.get(infilename, 0) + 1

    np_dict[infilename] /= (1.0 * len(all_lines))
    vp_dict[infilename] /= (1.0 * len(all_lines))
    tt_dict[infilename] /= (1.0 * len(all_lines))
    ctt_dict[infilename] /= (1.0 * len(all_lines))'''

    #print "Finished file", fID, "of", tot_count, ":", os.path.basename(infilename)


print "\n\nFirst sentences contain", len(count_f) * 100.0 / len(count_a), "% of all unique unigrams."
print "First sentences contain", len(first_dict) * 100.0 / len(key_dict), "% of all unique keyphrases."
print "Mean #sentences =", numpy.mean(count_sent), ", std =", numpy.std(count_sent), ", median =", numpy.median(count_sent), ", min =", min(count_sent), ", max =", max(count_sent), ".\n\n"

print len(np_dict) * 100.0 / len(key_dict), "% of all unique keyphrases are part of a noun phrase."
print len(vp_dict) * 100.0 / len(key_dict), "% of all unique keyphrases are part of a verb phrase."
print len(tt_dict) * 100.0 / len(key_dict), "% of all unique keyphrases are part of a technical term."
print len(ctt_dict) * 100.0 / len(key_dict), "% of all unique keyphrases are part of a compound technical term.\n\n"


'''print numpy.mean(np_dict.values()) * 100.0, "% of all unique keyphrases are part of a noun phrase."
print numpy.mean(vp_dict.values()) * 100.0, "% of all unique keyphrases are part of a verb phrase."
print numpy.mean(tt_dict.values()) * 100.0, "% of all unique keyphrases are part of a technical term."
print numpy.mean(ctt_dict.values()) * 100.0, "% of all unique keyphrases are part of a compound technical term.\n\n"'''



## Generate negative phrase examples for logistic regression.
## These are 78,160 random n-grams from abstracts (n = 1,2,3,4,5) that did not appear among human-chosen phrases.

## First collect the human-assigned keyphrases.
'''infile      =  open("phrases_with_less_than_six_words_that_appeared_in_corresponding_abstract.txt", "r")
human_keys  =  filter(lambda x: len(x) > 0, [line.strip() for line in infile.readlines()])
infile.close()

## Then obtain the negative keyphrases.
neg_keys    =  random.sample(list(set(dict_uni.keys() + dict_bi.keys() + dict_tri.keys() + dict_four.keys() + dict_five.keys()) - set(human_keys)), len(human_keys) * 10)

## Finally, write the negative examples out to a file.
outfile     =  open("negative_examples.txt", "w")
outfile.write("\n".join(neg_keys))
outfile.close()'''



