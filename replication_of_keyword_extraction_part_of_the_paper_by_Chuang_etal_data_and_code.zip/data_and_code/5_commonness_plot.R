cm = scan("corpus_commonness.txt")
png("corpus_commonness_histogram_minimum_frequency_cutoff_0.png")
hist(cm, breaks=seq(0,1,0.1), col="blue", border="white", main="", xlab="Corpus Commonness", ylab="Count of N-Grams")
dev.off()



