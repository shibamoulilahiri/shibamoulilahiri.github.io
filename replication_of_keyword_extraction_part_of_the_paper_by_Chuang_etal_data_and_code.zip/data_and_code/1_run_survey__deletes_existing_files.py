import glob, os, re
from xml.sax.saxutils import escape


hitTypeID_file = "HITs_with_HITTypeID"
if os.path.exists(hitTypeID_file): os.remove(hitTypeID_file)

indir      =  "/local/shibamouli/EECS592/SemEval_data/"
all_files  =  glob.glob(indir + "*")
tot_count  =  len(all_files)
assert(tot_count == 144)

outfile    =  open("SemEval_filenames", "w")
outfile.write("\n".join([os.path.basename(x).replace("SemEval_train_", "").replace(".txt", "") for x in all_files]))
outfile.close()

for fID, infilename in enumerate(all_files, 1):
    infile     =  open(infilename, "r")
    all_lines  =  filter(lambda x: len(x) > 0, [line.strip() for line in infile.readlines()])
    infile.close()
    title      =  escape(all_lines[0])
    abstract   =  "<br/><br/>".join([escape(line) for line in all_lines[1:]])

    infile     =  open("wellman_keywords.question", "r")
    content    =  infile.read()
    infile.close()

    content    =  re.sub("<h3>.*?</h3>", "<h3>" + title + "</h3>", content)
    content    =  re.sub("<p>.*?</p>", "<p>" + abstract + "</p>", content)

    outfile    =  open("wellman_keywords.question", "w")
    outfile.write(content)
    outfile.close()

    os.system("cd ../../; ant -DhitID=publishHIT wellman_keywords >> samples/wellman_project_keywords_survey/" + hitTypeID_file)

    print "Finished", fID, "of", tot_count, "files."



