/*
 * Copyright 2007-2012 Amazon Technologies, Inc.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at:
 * 
 * http://aws.amazon.com/apache2.0
 * 
 * This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES
 * OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and
 * limitations under the License.
 */ 


package wellman_project_keywords_survey;

import com.amazonaws.mturk.addon.HITQuestion;
import com.amazonaws.mturk.requester.Comparator;
import com.amazonaws.mturk.requester.HIT;
import com.amazonaws.mturk.requester.Locale;
import com.amazonaws.mturk.requester.QualificationRequirement;
import com.amazonaws.mturk.service.axis.RequesterService;
import com.amazonaws.mturk.util.PropertiesClientConfig;
import com.amazonaws.mturk.requester.Assignment;
import com.amazonaws.mturk.dataschema.QuestionFormAnswers;
import com.amazonaws.mturk.dataschema.QuestionFormAnswersType;

import java.util.List;
import java.io.*;
import org.apache.commons.lang3.StringEscapeUtils;

/**
 * The Keywords Survey application will create a HIT asking a worker to indicate
 * keywords for scientific abstracts.
 * 
 * mturk.properties must be found in the current file path.
 * 
 * The following concepts are covered:
 * - File based QAP HIT loading
 * - Using a locale qualification
 */

// Turker qualifications (ensure high qualification (Master?), native American English speaker). // Difficult to do, high qualification requirement dropped. Instead, mentioned native English speaker requirement in title and description. Also, "Locale = US" was enforced.
// When the HIT is finished, leave the turkers a "thank-you note" and a small token of appreciation (maybe something like a picture of a bunch of roses), so that they feel motivated and energized.
// Message: Thank you so much for successfully completing the assignment.
public class WellmanKeywords {

  private RequesterService service;

  //Defining the attributes of the HIT
  private String title = "Summarize content using keywords and keyphrases.";
  private String description = "For the given paper title and abstract, please summarize its content using five or more words, and/or phrases.";
  private int numAssignments = 69; // We need 69 persons to complete each HIT.
  private double reward = 0.05;
  private String keywords = "keyword, keyphrase, word, phrase, key word, key phrase, summary, summarize, summarization, content summarization, content, title, abstract, scientific document, scientific abstract, language, text, paper, papers";
  private long assignmentDurationInSeconds = 60 * 60; // 1 hour
  private long autoApprovalDelayInSeconds = 60*5; // 5 minutes. Originally, it was 60 * 60 * 24 * 15; // 15 days
  private long lifetimeInSeconds = 60 * 60 * 24 * 300; // 300 days
  private String requesterAnnotation = "sample#survey";
  
  //Defining the location of the externalized question (QAP) file.
  private String rootDir = ".";
  private String questionFile = rootDir + "/wellman_keywords.question";
  
  /**
   * Constructor
   *
   */
  public WellmanKeywords() {
    service = new RequesterService(new PropertiesClientConfig("../mturk.properties"));
  }
	
  /**
   * Checks to see if there are sufficient funds in your account to run this sample.
   * @return true if there are sufficient funds.  False if not.
   */
  public boolean hasEnoughFund() {
    double balance = service.getAccountBalance();
    System.out.println("Got account balance: " + RequesterService.formatCurrency(balance));
    return balance > 0;
  }
  
  /**
   * Creates the survey.
   *
   */
  public void createWellmanKeywordsSurvey() {
    try {

      // This is an example of creating a qualification.
      // This is a built-in qualification -- user must be based in the US
      QualificationRequirement qualReq1 = new QualificationRequirement();
      qualReq1.setQualificationTypeId(RequesterService.APPROVAL_RATE_QUALIFICATION_TYPE_ID);
      qualReq1.setComparator(Comparator.GreaterThanOrEqualTo);
      qualReq1.setIntegerValue(95);

      QualificationRequirement qualReq2 = new QualificationRequirement();
      qualReq2.setQualificationTypeId("00000000000000000040"); // Worker_NumberHITsApproved. Specifies the total number of HITs submitted by a Worker that have been approved. The value is an integer greater than or equal to 0.
      qualReq2.setComparator(Comparator.GreaterThanOrEqualTo);
      qualReq2.setIntegerValue(200);

      // The create HIT method takes in an array of QualificationRequirements
      // since a HIT can have multiple qualifications.
      QualificationRequirement[] qualReqs = null;
      qualReqs = new QualificationRequirement[] { qualReq1, qualReq2 };

      // Loading the question (QAP) file. HITQuestion is a helper class that
      // contains the QAP of the HIT defined in the external file. This feature 
      // allows you to write the entire QAP externally as a file and be able to 
      // modify it without recompiling your code.
      HITQuestion question = new HITQuestion(questionFile);
      
      //Creating the HIT and loading it into Mechanical Turk
      HIT hit = service.createHIT(null, // HITTypeId 
          title, 
          description, keywords, 
          question.getQuestion(),
          reward, assignmentDurationInSeconds,
          autoApprovalDelayInSeconds, lifetimeInSeconds,
          numAssignments, requesterAnnotation, 
          qualReqs,
          null // responseGroup
        );
      String hitId = hit.getHITId();
      System.out.println("Created HIT: " + hitId);

      System.out.println("You may see your HIT with HITTypeId '" 
          + hit.getHITTypeId() + "' here: ");
      
    } catch (Exception e) {
      System.err.println(e.getLocalizedMessage());
    }
  }

  public void retrieveAllHITs() {
    try {
      String hitId;
      int count = 0;
      BufferedReader br = new BufferedReader(new FileReader("hitIDs.txt"));
      PrintWriter outfile2 = new PrintWriter(new FileWriter("allAnswers.txt"));
      while ((hitId = br.readLine()) != null) {
        hitId = hitId.trim();
        Assignment[] assignments = service.getAllAssignmentsForHIT(hitId);
        PrintWriter outfile = new PrintWriter(new FileWriter("results/" + hitId + ".csv"));
        outfile.println ("HitId,AssignmentId,WorkerId,Status,AcceptTime,SubmitTime,Answer 1,Answer 2,Answer 3,Answer 4,Answer 5,Answer 6,Answer 7,Answer 8,Answer 9,Answer 10,Answer 11,Answer 12,Answer 13,Answer 14,Answer 15,Answer 16");
        if (assignments != null) {
          for (Assignment assignment : assignments) {
            outfile.print ( assignment.getHITId() + ","
                          + assignment.getAssignmentId() + ","
                          + assignment.getWorkerId() + ","
                          + assignment.getAssignmentStatus() + ","
                          + assignment.getAcceptTime().getTime() + ","
                          + assignment.getSubmitTime().getTime() + "," );

            //By default, answers are specified in XML
            String answerXML = assignment.getAnswer();

            //Calling a convenience method that will parse the answer XML and extract out the question/answer pairs.
            QuestionFormAnswers qfa = service.parseAnswers(answerXML);
            List<QuestionFormAnswersType.AnswerType> answers = (List<QuestionFormAnswersType.AnswerType>) qfa.getAnswer();

            if (answers != null) {
              int counter = -1;
              for (QuestionFormAnswersType.AnswerType answer : answers) {

                counter++;

                String assignmentId = assignment.getAssignmentId();
                String answerValue  = service.getAnswerValue(assignmentId, answer);

                if (counter > 0) outfile.print(",");

                //if (answerValue != null) outfile.print(answerValue);
                if (answerValue != null) {
                  outfile.print(StringEscapeUtils.escapeCsv(answerValue.trim().replace('\n', ' ').replace('\r', ' ')));
                  outfile2.println(StringEscapeUtils.escapeCsv(answerValue.trim().replace('\n', ' ').replace('\r', ' ')));
                }
              }
            }
            else outfile.print(",,,,,,,,,,,,,,,");
            outfile.println();
          }
        }
        outfile.close();
        count++;
        System.out.println("Finished retrieving " + count + " HITs.");
      }
      outfile2.close();
      br.close();

    } catch (Exception e) {
      System.err.println(e.getLocalizedMessage());
    }
  }

  public void expireAllHITs() {
    try {
      String aLine;
      int count = 0;
      // grep -i ted HITs_with_HITTypeID | cut -d':' -f2 > hitIDs_round1
      BufferedReader br = new BufferedReader(new FileReader("hitIDs_round1"));
      while ((aLine = br.readLine()) != null) {
        aLine = aLine.trim();
        service.forceExpireHIT(aLine);
        count++;
        System.out.println("Finished expiring " + count + " HITs.");
      }
      br.close();
    } catch (Exception e) {
      System.err.println(e.getLocalizedMessage());
    }
  }
  
   /**
   * @param args
   */
  public static void main(String[] args) {

    WellmanKeywords app = new WellmanKeywords();

    if (args[0].equals("publishHIT")) { // args[0] = "publishHIT"
      if (app.hasEnoughFund()) {
        app.createWellmanKeywordsSurvey();
      }
    }

    else if (args[0].equals("expireAllHITs")) { // args[0] = "expireAllHITs"
      app.expireAllHITs();
    }

    else if (args[0].equals("retrieveAllHITs")) { // args[0] = "retrieveAllHITs"
      app.retrieveAllHITs();
    }

    else {
      // Some problem. Don't handle this case.
    }

  }
}



