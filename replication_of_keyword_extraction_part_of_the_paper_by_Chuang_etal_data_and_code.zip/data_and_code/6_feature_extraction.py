# This script extracts features for descriptive keyphrase extraction.
# It extracts the following features for n-grams (n = 1, 2, 3, 4, 5):
#
# frequency + probabilistic:
# log_tf, tfidf, G_2, BM25, logOdds.
#
# commonness (corpus commonness based on INSPEC)
#
# grammatical (part-of-speech-based and parser-based features)
# positional (first occurrence, relative first occurrence, presence in first sentence)
#
# as described in the paper.
#
# The script stores all these features in R matrix format.
# Rows are positive and negative keyphrase examples.
# Columns are the features.


import glob, math, os, re
from nltk.tokenize import sent_tokenize


## First collect the human-assigned keyphrases (positive examples).
infile      =  open("phrases_with_less_than_six_words_that_appeared_in_corresponding_abstract.txt", "r")
human_keys  =  filter(lambda x: len(x) > 0, [line.strip() for line in infile.readlines()])
infile.close()
assert(len(human_keys) == 7816)


## Then collect the negative examples.
infile      =  open("negative_examples.txt", "r")
neg_keys    =  filter(lambda x: len(x) > 0, [line.strip() for line in infile.readlines()])
infile.close()
assert(len(neg_keys) == 78160)


## Now collect t_Doc and T_Doc.

indir       =  "/local/shibamouli/EECS592/SemEval_data_abstracts_only/"
all_files   =  glob.glob(indir + "*txt")
tot_count   =  len(all_files)
assert(tot_count == 144)

np          =  {}  # Collects noun phrases
vp          =  {}  # Collects verb phrases
hn          =  {}  # Collects head nouns
tt          =  {}  # Collects technical terms
ctt         =  {}  # Collects compound technical terms
olw         =  {}  # Collects optional leading words

t_Doc       =  {}  # Stores n-grams with counts.
t_p_Doc     =  {}  # Stores n-grams with weighted counts.
t_Doc_local =  {}  # Local version of t_Doc

fo          =  {}  # Stores first occurrence.
afo         =  {}  # Stores absolute first occurrence.
rfo         =  {}  # Stores relative first occurrence.
pfs         =  {}  # Stores presence in first sentence.

T_Doc       =  0
T_p_Doc     =  0
for fID, infilename in enumerate(all_files, 1):
    ## First collect noun phrases, verb phrases, technical terms, compound technical terms, optional leading words, head nouns.
    infile       =  open(infilename.replace(".txt", ".noun_phrases"), "r")
    all_lines    =  filter(lambda x: len(x) > 0, [line.strip() for line in infile.readlines()])
    np.update({y : 0 for y in all_lines})
    head_nouns   =  filter(lambda x: len(x) > 0, [line.split()[-1] for line in all_lines])
    hn.update({y : 0 for y in head_nouns})
    infile.close()
    infile       =  open(infilename.replace(".txt", ".verb_phrases"), "r")
    all_lines    =  filter(lambda x: len(x) > 0, [line.strip() for line in infile.readlines()])
    vp.update({y : 0 for y in all_lines})
    infile.close()
    infile       =  open(infilename.replace(".txt", ".technical_terms"), "r")
    all_lines    =  filter(lambda x: len(x) > 0, [line.strip() for line in infile.readlines()])
    tt.update({y : 0 for y in all_lines})
    infile.close()
    infile       =  open(infilename.replace(".txt", ".compound_technical_terms"), "r")
    all_lines    =  filter(lambda x: len(x) > 0, [line.strip() for line in infile.readlines()])
    ctt.update({y : 0 for y in all_lines})
    infile.close()
    infile       =  open(infilename.replace(".txt", ".optional_leading_words"), "r")
    all_lines    =  filter(lambda x: len(x) > 0, [line.strip() for line in infile.readlines()])
    olw.update({y : 0 for y in all_lines})
    infile.close()

    ## Then collect the remaining information.
    infile       =  open(infilename, "r")
    all_lines    =  filter(lambda x: len(x) > 0, [line.strip() for line in infile.readlines()])
    infile.close()

    abstract     =  " ".join(all_lines)
    big_text     =  re.sub("\s+", " ", abstract)
    unigrams     =  big_text.split()
    bigrams      =  [" ".join(x) for x in zip(unigrams, unigrams[1:])]
    trigrams     =  [" ".join(x) for x in zip(unigrams, unigrams[1:], unigrams[2:])]
    fourgrams    =  [" ".join(x) for x in zip(unigrams, unigrams[1:], unigrams[2:], unigrams[3:])]
    fivegrams    =  [" ".join(x) for x in zip(unigrams, unigrams[1:], unigrams[2:], unigrams[3:], unigrams[4:])]

    sentences    =  sent_tokenize(abstract)
    first_sent   =  sentences[0]
    first_sent_1 =  first_sent.split()
    first_sent_2 =  [" ".join(x) for x in zip(first_sent_1, first_sent_1[1:])]
    first_sent_3 =  [" ".join(x) for x in zip(first_sent_1, first_sent_1[1:], first_sent_1[2:])]
    first_sent_4 =  [" ".join(x) for x in zip(first_sent_1, first_sent_1[1:], first_sent_1[2:], first_sent_1[3:])]
    first_sent_5 =  [" ".join(x) for x in zip(first_sent_1, first_sent_1[1:], first_sent_1[2:], first_sent_1[3:], first_sent_1[4:])]
    pfs.update({y : 0 for y in first_sent_1 + first_sent_2 + first_sent_3 + first_sent_4 + first_sent_5})

    t_Doc_local  =  {}

    for yi, y in enumerate(unigrams):
        t_Doc[y]      =  t_Doc.get(y, 0)   + 1
        t_p_Doc[y]    =  t_p_Doc.get(y, 0) + 0.01
        t_Doc_local[y]=  t_Doc_local.get(y, 0)   + 1
        T_Doc        +=  1
        T_p_Doc      +=  0.01
        if (y not in fo) or yi < fo[y]: fo[y] = yi

    for yi, y in enumerate(bigrams):
        t_Doc[y]      =  t_Doc.get(y, 0)   + 1
        t_p_Doc[y]    =  t_p_Doc.get(y, 0) + 0.01
        t_Doc_local[y]=  t_Doc_local.get(y, 0)   + 1
        if (y not in fo) or yi < fo[y]: fo[y] = yi

    for yi, y in enumerate(trigrams):
        t_Doc[y]      =  t_Doc.get(y, 0)   + 1
        t_p_Doc[y]    =  t_p_Doc.get(y, 0) + 0.01
        t_Doc_local[y]=  t_Doc_local.get(y, 0)   + 1
        if (y not in fo) or yi < fo[y]: fo[y] = yi

    for yi, y in enumerate(fourgrams):
        t_Doc[y]      =  t_Doc.get(y, 0)   + 1
        t_p_Doc[y]    =  t_p_Doc.get(y, 0) + 0.01
        t_Doc_local[y]=  t_Doc_local.get(y, 0)   + 1
        if (y not in fo) or yi < fo[y]: fo[y] = yi

    for yi, y in enumerate(fivegrams):
        t_Doc[y]      =  t_Doc.get(y, 0)   + 1
        t_p_Doc[y]    =  t_p_Doc.get(y, 0) + 0.01
        t_Doc_local[y]=  t_Doc_local.get(y, 0)   + 1
        if (y not in fo) or yi < fo[y]: fo[y] = yi

    for y in unigrams:  afo[y] = fo[y] * 1.0 / len(unigrams)
    for y in bigrams:   afo[y] = fo[y] * 1.0 / len(unigrams)
    for y in trigrams:  afo[y] = fo[y] * 1.0 / len(unigrams)
    for y in fourgrams: afo[y] = fo[y] * 1.0 / len(unigrams)
    for y in fivegrams: afo[y] = fo[y] * 1.0 / len(unigrams)

    for y in unigrams:  rfo[y] = pow(1 - afo[y], t_Doc_local[y])
    for y in bigrams:   rfo[y] = pow(1 - afo[y], t_Doc_local[y])
    for y in trigrams:  rfo[y] = pow(1 - afo[y], t_Doc_local[y])
    for y in fourgrams: rfo[y] = pow(1 - afo[y], t_Doc_local[y])
    for y in fivegrams: rfo[y] = pow(1 - afo[y], t_Doc_local[y])

    print "Collecting t_Doc: Finished file", fID, "of", tot_count, "-", os.path.basename(infilename)


## Then collect t_Ref and T_Ref.

indir       =  "/local/shibamouli/EECS592/replication_project/INSPEC/all_texts/"
all_files   =  glob.glob(indir + "*txt")
tot_count   =  len(all_files)
assert(tot_count == 2000)

dict_comm   =  {}  # Stores count of n-grams, in reference corpus.
for i in range(1, 6): dict_comm[i] = {}

t_Ref       =  {}  # Stores n-grams with counts, in reference corpus.
t_Doc_bar   =  {}
t_p_Doc_bar =  {}

N           =  tot_count
T_Ref       =  0
T_Doc_bar   =  0
T_p_Doc_bar =  0
D           =  {}
for fID, infilename in enumerate(all_files, 1):
    infile       =  open(infilename, "r")
    all_lines    =  filter(lambda x: len(x) > 0, [line.strip() for line in infile.readlines()])
    all_lines    =  filter(lambda x: len(x) > 0, [re.sub("\s+", " ", line.replace("\n", " ").replace("\r", " ").strip()) for line in all_lines])
    big_text     =  " ".join(all_lines)
    infile.close()

    unigrams     =  big_text.split()
    bigrams      =  [" ".join(x) for x in zip(unigrams, unigrams[1:])]
    trigrams     =  [" ".join(x) for x in zip(unigrams, unigrams[1:], unigrams[2:])]
    fourgrams    =  [" ".join(x) for x in zip(unigrams, unigrams[1:], unigrams[2:], unigrams[3:])]
    fivegrams    =  [" ".join(x) for x in zip(unigrams, unigrams[1:], unigrams[2:], unigrams[3:], unigrams[4:])]

    for y in unigrams:
        dict_comm[1][y] =  dict_comm[1].get(y, 0) + 1
        t_Ref[y]        =  t_Ref.get(y, 0)  + 1
        T_Ref          +=  1
        if y not in t_Doc:
            t_Doc_bar[y]   =  t_Doc_bar.get(y, 0) + 1
            t_p_Doc_bar[y] =  t_p_Doc_bar.get(y, 0) + 0.01
            T_Doc_bar  +=  1
            T_p_Doc_bar+=  0.01

    for y in bigrams:
        dict_comm[2][y] =  dict_comm[2].get(y, 0) + 1
        t_Ref[y]        =  t_Ref.get(y, 0)  + 1
        if y not in t_Doc:
            t_Doc_bar[y]   =  t_Doc_bar.get(y, 0) + 1
            t_p_Doc_bar[y] =  t_p_Doc_bar.get(y, 0) + 0.01

    for y in trigrams:
        dict_comm[3][y] =  dict_comm[3].get(y, 0) + 1
        t_Ref[y]        =  t_Ref.get(y, 0)  + 1
        if y not in t_Doc:
            t_Doc_bar[y]   =  t_Doc_bar.get(y, 0) + 1
            t_p_Doc_bar[y] =  t_p_Doc_bar.get(y, 0) + 0.01

    for y in fourgrams:
        dict_comm[4][y] =  dict_comm[4].get(y, 0) + 1
        t_Ref[y]        =  t_Ref.get(y, 0)  + 1
        if y not in t_Doc:
            t_Doc_bar[y]   =  t_Doc_bar.get(y, 0) + 1
            t_p_Doc_bar[y] =  t_p_Doc_bar.get(y, 0) + 0.01

    for y in fivegrams:
        dict_comm[5][y] =  dict_comm[5].get(y, 0) + 1
        t_Ref[y]        =  t_Ref.get(y, 0)  + 1
        if y not in t_Doc:
            t_Doc_bar[y]   =  t_Doc_bar.get(y, 0) + 1
            t_p_Doc_bar[y] =  t_p_Doc_bar.get(y, 0) + 0.01

    for y in set(unigrams + bigrams + trigrams + fourgrams + fivegrams): D[y] = D.get(y, 0) + 1

    print "Collecting t_Ref: Finished file", fID, "of", tot_count, "-", os.path.basename(infilename)

r           =  T_Ref * 1.0 / N


## Write out features for positive and negative examples.
max_dict    =  {}
max_dict[1] =  max(dict_comm[1].values())
max_dict[2] =  max(dict_comm[2].values())
max_dict[3] =  max(dict_comm[3].values())
max_dict[4] =  max(dict_comm[4].values())
max_dict[5] =  max(dict_comm[5].values())

outfile     =  open("all_features.txt", "w")
outfile.write("is_keyphrase log_tf tfidf G_2 BM25 logOdds commonness full_np full_vp partial_np partial_vp first_word_olw last_word_head_noun full_tt full_ctt partial_tt partial_ctt presence_in_first_sentence absolute_first_occurrence relative_first_occurrence\n")

tot_p       =  len(human_keys)
for pid, phrase in enumerate(human_keys, 1):
    x       =  len(filter(lambda x: len(x) > 0, phrase.split()))
    log_tf  =  str(math.log(t_Doc[phrase]) if phrase in t_Doc else 0)
    tfidf   =  str((t_Doc[phrase] if phrase in t_Doc else 0) * 1.0 / (t_Ref[phrase] if phrase in t_Ref else 1) * math.log(N * 1.0 / (D[phrase] if phrase in D else 1)))
    G_2     =  str(2 * ((t_Doc[phrase] if phrase in t_Doc else 0) * math.log((t_Doc[phrase] if phrase in t_Doc else 1) * T_Ref * 1.0 / (T_Doc * T_Doc)) + (t_Doc_bar[phrase] if phrase in t_Doc_bar else 0) * math.log((t_Doc_bar[phrase] if phrase in t_Doc_bar else 1) * T_Ref * 1.0 / (T_Doc_bar * T_Doc))))
    BM25    =  str(3.0 * (t_Doc[phrase] if phrase in t_Doc else 0) / ((t_Doc[phrase] if phrase in t_Doc else 0) + 2 * (0.25 + 0.75 * T_Doc / r)) * math.log(N * 1.0 / (D[phrase] if phrase in D else 1)))
    logOdds =  str((math.log((t_p_Doc[phrase] if phrase in t_p_Doc else 1) * 1.0 / (t_p_Doc_bar[phrase] if phrase in t_p_Doc_bar else 1)) - math.log(T_p_Doc * 1.0 / T_p_Doc_bar)) / math.sqrt(1.0/(t_p_Doc[phrase] if phrase in t_p_Doc else 1) + 1.0/(t_p_Doc_bar[phrase] if phrase in t_p_Doc_bar else 1)))
    common  =  str(math.log((dict_comm[x][phrase] if phrase in dict_comm[x] else 1))/math.log(max_dict[x]))
    full_np =  str(1 if phrase in np else 0)
    full_vp =  str(1 if phrase in vp else 0)
    partial_np =  0
    partial_vp =  0
    for x in np:
        if phrase in x:
            partial_np   =  1
            break
    for x in vp:
        if phrase in x:
            partial_vp   =  1
            break
    partial_np =  str(partial_np)
    partial_vp =  str(partial_vp)
    first_w =  phrase.split()[0]
    last_w  =  phrase.split()[-1]
    first_word_olw       =  str(1 if first_w in olw else 0)
    last_word_head_noun  =  str(1 if last_w in hn else 0)
    full_tt              =  str(1 if phrase in tt else 0)
    full_ctt             =  str(1 if phrase in ctt else 0)
    partial_tt           =  0
    partial_ctt          =  0
    for x in tt:
        if phrase in x:
            partial_tt   =  1
            break
    for x in ctt:
        if phrase in x:
            partial_ctt  =  1
            break
    partial_tt           =  str(partial_tt)
    partial_ctt          =  str(partial_ctt)
    presence             =  str(1 if phrase in pfs else 0)
    this_afo             =  str(afo[phrase] if phrase in afo else -1)
    this_rfo             =  str(rfo[phrase] if phrase in rfo else -1)
    outfile.write("1 " + " ".join([log_tf, tfidf, G_2, BM25, logOdds, common, full_np, full_vp, partial_np, partial_vp, first_word_olw, last_word_head_noun, full_tt, full_ctt, partial_tt, partial_ctt, presence, this_afo, this_rfo]) + "\n")
    if pid % 1000 == 0: print "Finished", pid, "of", tot_p, "positive examples."


tot_p       =  len(neg_keys)
for pid, phrase in enumerate(neg_keys, 1):
    x       =  len(filter(lambda x: len(x) > 0, phrase.split()))
    log_tf  =  str(math.log(t_Doc[phrase]) if phrase in t_Doc else 0)
    tfidf   =  str((t_Doc[phrase] if phrase in t_Doc else 0) * 1.0 / (t_Ref[phrase] if phrase in t_Ref else 1) * math.log(N * 1.0 / (D[phrase] if phrase in D else 1)))
    G_2     =  str(2 * ((t_Doc[phrase] if phrase in t_Doc else 0) * math.log((t_Doc[phrase] if phrase in t_Doc else 1) * T_Ref * 1.0 / (T_Doc * T_Doc)) + (t_Doc_bar[phrase] if phrase in t_Doc_bar else 0) * math.log((t_Doc_bar[phrase] if phrase in t_Doc_bar else 1) * T_Ref * 1.0 / (T_Doc_bar * T_Doc))))
    BM25    =  str(3.0 * (t_Doc[phrase] if phrase in t_Doc else 0) / ((t_Doc[phrase] if phrase in t_Doc else 0) + 2 * (0.25 + 0.75 * T_Doc / r)) * math.log(N * 1.0 / (D[phrase] if phrase in D else 1)))
    logOdds =  str((math.log((t_p_Doc[phrase] if phrase in t_p_Doc else 1) * 1.0 / (t_p_Doc_bar[phrase] if phrase in t_p_Doc_bar else 1)) - math.log(T_p_Doc * 1.0 / T_p_Doc_bar)) / math.sqrt(1.0/(t_p_Doc[phrase] if phrase in t_p_Doc else 1) + 1.0/(t_p_Doc_bar[phrase] if phrase in t_p_Doc_bar else 1)))
    common  =  str(math.log((dict_comm[x][phrase] if phrase in dict_comm[x] else 1))/math.log(max_dict[x]))
    full_np =  str(1 if phrase in np else 0)
    full_vp =  str(1 if phrase in vp else 0)
    partial_np =  0
    partial_vp =  0
    for x in np:
        if phrase in x:
            partial_np   =  1
            break
    for x in vp:
        if phrase in x:
            partial_vp   =  1
            break
    partial_np =  str(partial_np)
    partial_vp =  str(partial_vp)
    first_w =  phrase.split()[0]
    last_w  =  phrase.split()[-1]
    first_word_olw       =  str(1 if first_w in olw else 0)
    last_word_head_noun  =  str(1 if last_w in hn else 0)
    full_tt              =  str(1 if phrase in tt else 0)
    full_ctt             =  str(1 if phrase in ctt else 0)
    partial_tt           =  0
    partial_ctt          =  0
    for x in tt:
        if phrase in x:
            partial_tt   =  1
            break
    for x in ctt:
        if phrase in x:
            partial_ctt  =  1
            break
    partial_tt           =  str(partial_tt)
    partial_ctt          =  str(partial_ctt)
    presence             =  str(1 if phrase in pfs else 0)
    this_afo             =  str(afo[phrase] if phrase in afo else -1)
    this_rfo             =  str(rfo[phrase] if phrase in rfo else -1)
    outfile.write("0 " + " ".join([log_tf, tfidf, G_2, BM25, logOdds, common, full_np, full_vp, partial_np, partial_vp, first_word_olw, last_word_head_noun, full_tt, full_ctt, partial_tt, partial_ctt, presence, this_afo, this_rfo]) + "\n")
    if pid % 1000 == 0: print "Finished", pid, "of", tot_p, "negative examples."
outfile.close()



