library(ROCR)

png("adding_term_commonness.png")

mydata = read.table("all_features.txt", header=TRUE)
mymodel = glm(is_keyphrase~log_tf+commonness, data=mydata, family=binomial(logit), weights=c(rep(1,times=7816), rep(0.1,times=78160)))
mydata$predictions = predict(mymodel, newdata = mydata, type="response")
pred = prediction(mydata$predictions, mydata$is_keyphrase)
perf = performance(pred, measure = "prec", x.measure = "rec") 
plot(perf, col="red", lwd=4)
par(new=T, xaxt="n", yaxt="n", ann=FALSE)

mydata = read.table("all_features.txt", header=TRUE)
mymodel = glm(is_keyphrase~G_2, data=mydata, family=binomial(logit), weights=c(rep(1,times=7816), rep(0.1,times=78160)))
mydata$predictions = predict(mymodel, newdata = mydata, type="response")
pred = prediction(mydata$predictions, mydata$is_keyphrase)
perf = performance(pred, measure = "prec", x.measure = "rec") 
plot(perf, col="black", lwd=4)
par(new=T, xaxt="n", yaxt="n", ann=FALSE)

mydata = read.table("all_features.txt", header=TRUE)
mymodel = glm(is_keyphrase~log_tf, data=mydata, family=binomial(logit), weights=c(rep(1,times=7816), rep(0.1,times=78160)))
mydata$predictions = predict(mymodel, newdata = mydata, type="response")
pred = prediction(mydata$predictions, mydata$is_keyphrase)
perf = performance(pred, measure = "prec", x.measure = "rec") 
plot(perf, col="blue", lwd=4)

legend("topright", c("log(tf) + commonness","G_2","log(tf)"), text.col=c("red","black","blue"), col=c("red","black","blue"), lwd=4)

dev.off()



