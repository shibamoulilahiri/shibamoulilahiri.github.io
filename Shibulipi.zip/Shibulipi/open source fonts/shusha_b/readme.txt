This is the Readme.txt file of Bangla Shusha True Type Fonts (beta version).
This is based on Shusha version 1.6. This is a E-Mailware. Please use & 
distribute it freely. 

Just E-Mail your comments to me.

Please do followings:

Install the Shusha fonts - Shyma01.ttf  

	- Control Panel-Fonts-File-Install New Fonts

You can now use these fonts in all windows aplications. The detailed 
key Map is in the file keybd_b.pdf.

Please use and distribut these. please let me have your comments 
so that this beta version can be improved and final version can 
be released.

Please do send me your comments.

Harsh Kumar	
harshkumar@poboxes.com
