The "data" directory contains 3,000 text passages.

The passages are divided into balanced train, test, and dev sets - as indicated by file names.

The file "labels.txt" contains class labels.

First column is the class label (author name).

Second column is the file name.



